require('dotenv').config({ path: '.env.local' });
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const logger = require('./utils/logger');
const { errorHandler } = require('./middleware/errorHandler');

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
  });
});

app.get('/', (req, res) => {
  res.json({
    message: '🍽️ TableShare API',
    version: '1.0.0',
    endpoints: {
      health: '/health',
      auth: '/api/v1/auth',
      restaurants: '/api/v1/restaurants',
    },
  });
});

const authRoutes = require('./routes/auth.routes');
const restaurantRoutes = require('./routes/restaurant.routes');

app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/restaurants', restaurantRoutes);

app.use(errorHandler);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🍽️  TableShare API Running!`);
  console.log(`📍 http://localhost:${PORT}`);
  console.log(`🔐 Auth: /api/v1/auth`);
  console.log(`🏪 Restaurants: /api/v1/restaurants\n`);
});
