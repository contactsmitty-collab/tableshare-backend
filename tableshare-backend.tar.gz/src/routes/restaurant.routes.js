const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { asyncHandler } = require('../middleware/errorHandler');

router.get('/featured', asyncHandler(async (req, res) => {
  const result = await query('SELECT * FROM restaurants LIMIT 10');
  res.json({ restaurants: result.rows });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const result = await query(
    'SELECT * FROM restaurants WHERE restaurant_id = $1',
    [req.params.id]
  );
  res.json({ restaurant: result.rows[0] || null });
}));

module.exports = router;
